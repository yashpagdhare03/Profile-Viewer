// MapComponent.js
import React,{useState,useEffect} from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import { geocodeAddress } from './GeoCode';

function MapComponent({ address }){

  const [location, setLocation] = useState(null);
  useEffect(() => {
    geocodeAddress(address)
      .then((coords) => setLocation(coords))
      .catch((error) => console.error('Error geocoding address:', error));
  }, [address]);
  const mapStyles = { height: "400px", width: "100%" };
  const apiKey=import.meta.env.VITE_API_KEY;
  const defaultCenter = {
    lat: 37.7749, lng: -122.4194
  };

  return (
    <LoadScript googleMapsApiKey={apiKey}>
      <GoogleMap
        mapContainerStyle={mapStyles}
        zoom={13}
        center={defaultCenter}
      >
      {location && <Marker position={location} />}
      </GoogleMap>
    </LoadScript>
  )
};

export default MapComponent;
