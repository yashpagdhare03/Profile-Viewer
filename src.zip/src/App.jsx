// App.jsx
import React, { useState } from 'react';
import ProfileList from './ProfileList';
import SearchBar from './SearchBar';
import AdminPanel from './AdminPanel';

function App() {
  const [profiles, setProfiles] = useState([
    { id: 1, name: 'John Doe', photo: 'https://via.placeholder.com/100', description: 'Software Engineer', address: { lat: 37.7749, lng: -122.4194 } },
    { id: 2, name: 'Jane Smith', photo: 'https://via.placeholder.com/100', description: 'UI/UX Designer', address: { lat: 34.0522, lng: -118.2437 } },
    { id: 3, name: 'Sam Johnson', photo: 'https://via.placeholder.com/100', description: 'Project Manager', address: { lat: 40.7128, lng: -74.0060 } },
    { id: 4, name: 'sanuel', photo: 'https://via.placeholder.com/100', description: 'Project Manager', address: 'Pune' },
  ]);

  const [filteredProfiles, setFilteredProfiles] = useState(profiles);

  // UseEffect to update the filteredProfiles when profiles change
  React.useEffect(() => {
    setFilteredProfiles(profiles);
  }, [profiles]);

  return (
    <div className="container">
      <h1>Profile Viewer and Map Explorer</h1>

      {/* Search Bar */}
      <SearchBar profiles={profiles} setFilteredProfiles={setFilteredProfiles} />

      {/* Profile List */}
      <ProfileList profiles={filteredProfiles} />

      {/* Admin Panel */}
      <h2>Admin Panel</h2>
      <AdminPanel profiles={profiles} setProfiles={setProfiles} />
    </div>
  );
};

export default App;


