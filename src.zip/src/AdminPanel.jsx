// AdminPanel.js
import React, { useState } from 'react';

function AdminPanel({ profiles, setProfiles }){
  const [newProfile, setNewProfile] = useState({
    name: '', 
    photo: '', 
    description: '', 
    address: { lat: '', lng: '' }
  });

  function handleChange(e){
    const { name, value } = e.target;

    if (name === 'lat' || name === 'lng') {
      setNewProfile(prev => ({
        ...prev,
        address: { ...prev.address, [name]: value }
      }));
    } else {
      setNewProfile(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  function addProfile(){
    if (newProfile.name && newProfile.photo && newProfile.description && newProfile.address.lat && newProfile.address.lng) {
      setProfiles(prevProfiles => {
        const updatedProfiles = [...prevProfiles, { ...newProfile, id: prevProfiles.length + 1 }];
        console.log('Updated Profiles:', updatedProfiles); // Debugging
        return updatedProfiles;
      });
      
      setNewProfile({ name: '', photo: '', description: '', address: { lat: '', lng:  ''} });
    } else {
      alert('Please fill out all fields');
    }
  };

  return (
    <div className="admin-panel">
      <input 
        name="name" 
        value={newProfile.name} 
        onChange={handleChange} 
        placeholder="Name" 
      />
      <input 
        name="photo" 
        value={newProfile.photo} 
        onChange={handleChange} 
        placeholder="Photo URL" 
      />
      <input 
        name="description" 
        value={newProfile.description} 
        onChange={handleChange} 
        placeholder="Description" 
      />
      <input 
        name="lat" 
        value={newProfile.address.lat} 
        onChange={handleChange} 
        placeholder="Latitude" 
      />
      <input 
        name="lng" 
        value={newProfile.address.lng} 
        onChange={handleChange} 
        placeholder="Longitude" 
      />
      <button onClick={addProfile}>Add Profile</button>
    </div>
  );
};

export default AdminPanel;
