// ProfileCard.js
import React from 'react';

function ProfileCard({ profile, onShowMap }){
  return (
    <div className="profile-card">
      <img src={profile.photo} alt={profile.name} />
      <h3>{profile.name}</h3>
      <p>{profile.description}</p>
      <button onClick={() => onShowMap(profile.address)}>Show Address on Map</button>
    </div>
  );
};

export default ProfileCard;
